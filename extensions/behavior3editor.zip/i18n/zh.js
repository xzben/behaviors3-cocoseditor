/*
 * @Author: xzben
 * @Date: 2022-05-30 19:51:31
 * @LastEditors: xzben
 * @LastEditTime: 2022-05-30 20:11:57
 * @Description: file content
 */
"use strict";
module.exports={
    open_panel:"打开Editor",
    description:"含有一个面板的扩展",
    path_root : "Behavior3Editor",
};