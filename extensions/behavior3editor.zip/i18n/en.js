/*
 * @Author: xzben
 * @Date: 2022-05-30 19:51:31
 * @LastEditors: xzben
 * @LastEditTime: 2022-06-01 14:27:47
 * @Description: file content
 */
"use strict";
module.exports={
    open_panel:"Open Tool",
    description:"Extension with a panel",
    path_root : "Behavior3Editor",
    open_setting_panel : "OpenSetting",
};